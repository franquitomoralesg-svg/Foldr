# Genera icon.png (256) y tray.png (32) a partir de assets/logo.png.
Add-Type -AssemblyName System.Drawing

$root = if ($PSScriptRoot) { Split-Path $PSScriptRoot -Parent } else { "C:\Users\franc\carpetas-hyperos" }
$assets = Join-Path $root "assets"
$logo = Join-Path $assets "logo.png"

function Save-ResizedIcon([string]$src, [int]$size, [int]$fit, [string]$out) {
  $content = New-Object System.Drawing.Bitmap $src
  $bmp = New-Object System.Drawing.Bitmap $size, $size
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
  $g.Clear([System.Drawing.Color]::FromArgb(0, 0, 0, 0))
  $scale = [Math]::Min($fit / $content.Width, $fit / $content.Height)
  $w = [Math]::Max(1, [int][Math]::Round($content.Width * $scale))
  $h = [Math]::Max(1, [int][Math]::Round($content.Height * $scale))
  $attr = New-Object System.Drawing.Imaging.ImageAttributes
  $attr.SetWrapMode([System.Drawing.Drawing2D.WrapMode]::TileFlipXY)
  $dst = New-Object System.Drawing.Rectangle ((($size - $w) / 2), (($size - $h) / 2), $w, $h)
  $g.DrawImage($content, $dst, 0, 0, $content.Width, $content.Height, [System.Drawing.GraphicsUnit]::Pixel, $attr)
  $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
  $g.Dispose(); $bmp.Dispose(); $content.Dispose(); $attr.Dispose()
}

if (-not (Test-Path $logo)) {
  Write-Error "Falta $logo (es la fuente de todos los iconos)."
  exit 1
}
Save-ResizedIcon $logo 256 236 (Join-Path $assets "icon.png")
Save-ResizedIcon $logo 32 28 (Join-Path $assets "tray.png")
Write-Output (Get-ChildItem $assets -Filter *.png | Select-Object Name, Length | Out-String)
