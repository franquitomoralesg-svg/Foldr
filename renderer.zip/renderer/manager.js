const foldersEl = document.getElementById("folders");
const loginEl = document.getElementById("login");

const FOLDER_COLORS = [
  "",
  "#4c7dff",
  "#7c4dff",
  "#e0567a",
  "#ff8a3d",
  "#f5c542",
  "#3ecf8e",
  "#22b8cf",
  "#96a0b5",
];
const ICON_OPTIONS = [
  ["small", "Chicos"],
  ["normal", "Normales"],
  ["large", "Grandes"],
];
const SIZE_LIMITS = { min: 120, max: 280, step: 10, default: 180 };
const ICON_SIZES = ["small", "normal", "large"];
// Qué carpetas están desplegadas (se conserva al rehacer la lista).
const openFolders = new Set();

function setIcon(node, app) {
  node.replaceChildren();
  if (app?.icon && String(app.icon).startsWith("data:")) {
    const image = document.createElement("img");
    image.src = app.icon;
    image.alt = app.name || "";
    node.appendChild(image);
    return;
  }
  node.textContent = (app?.name || "?").slice(0, 1).toUpperCase();
}

function clamp(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

function settingRow(label, control) {
  const row = document.createElement("div");
  row.className = "setting";
  const name = document.createElement("span");
  name.className = "setting-label";
  name.textContent = label;
  row.append(name, control);
  return row;
}

function slider(label, { min, max, step, value, format, onInput }) {
  const row = document.createElement("label");
  row.className = "setting";
  const name = document.createElement("span");
  name.className = "setting-label";
  name.textContent = label;
  const input = document.createElement("input");
  input.type = "range";
  input.min = min;
  input.max = max;
  input.step = step;
  input.value = value;
  const out = document.createElement("output");
  out.textContent = format(Number(value));
  input.addEventListener("input", () => {
    out.textContent = format(Number(input.value));
    onInput(Number(input.value));
  });
  row.append(name, input, out);
  return row;
}

function segmented(options, current, onPick) {
  const wrap = document.createElement("div");
  wrap.className = "segmented";
  options.forEach(([value, label]) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    if (value === current) button.classList.add("active");
    button.addEventListener("click", () => {
      wrap.querySelectorAll("button").forEach((other) => other.classList.remove("active"));
      button.classList.add("active");
      onPick(value);
    });
    wrap.appendChild(button);
  });
  return wrap;
}

function toggleChip(label, value, onPick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "chip";
  const paint = (enabled) => {
    button.textContent = `${label} · ${enabled ? "Sí" : "No"}`;
    button.classList.toggle("off", !enabled);
  };
  paint(value);
  button.addEventListener("click", () => {
    const next = button.classList.contains("off");
    paint(next);
    onPick(next);
  });
  return button;
}

function buildSettings(folder, patch) {
  const wrap = document.createElement("div");
  wrap.className = "settings";

  const colorRow = document.createElement("div");
  colorRow.className = "setting";
  const colorLabel = document.createElement("span");
  colorLabel.className = "setting-label";
  colorLabel.textContent = "Color";
  const swatches = document.createElement("div");
  swatches.className = "swatches";
  FOLDER_COLORS.forEach((color) => {
    const swatch = document.createElement("button");
    swatch.type = "button";
    swatch.className = "swatch";
    swatch.title = color || "Sin color";
    if (color) {
      swatch.style.background = color;
    } else {
      swatch.classList.add("none");
    }
    if ((folder.color || "") === color) swatch.classList.add("active");
    swatch.addEventListener("click", () => {
      swatches.querySelectorAll(".swatch").forEach((other) => other.classList.remove("active"));
      swatch.classList.add("active");
      patch({ color });
    });
    swatches.appendChild(swatch);
  });
  colorRow.append(colorLabel, swatches);

  const emojiRow = document.createElement("label");
  emojiRow.className = "setting";
  const emojiLabel = document.createElement("span");
  emojiLabel.className = "setting-label";
  emojiLabel.textContent = "Emoji";
  const emojiInput = document.createElement("input");
  emojiInput.className = "emoji-input";
  emojiInput.type = "text";
  emojiInput.maxLength = 4;
  emojiInput.placeholder = "—";
  emojiInput.value = folder.emoji || "";
  emojiInput.addEventListener("change", () => patch({ emoji: emojiInput.value }));
  emojiRow.append(emojiLabel, emojiInput);

  const size = clamp(folder.size, SIZE_LIMITS.min, SIZE_LIMITS.max, SIZE_LIMITS.default);
  const opacity = clamp(folder.opacity, 0, 100, 25);
  const iconSize = ICON_SIZES.includes(folder.iconSize) ? folder.iconSize : "normal";

  wrap.append(
    colorRow,
    emojiRow,
    slider("Tamaño", {
      min: SIZE_LIMITS.min,
      max: SIZE_LIMITS.max,
      step: SIZE_LIMITS.step,
      value: size,
      format: (value) => `${value} px`,
      onInput: (value) => patch({ size: value }),
    }),
    slider("Opacidad", {
      min: 0,
      max: 100,
      step: 5,
      value: opacity,
      format: (value) => `${value} %`,
      onInput: (value) => patch({ opacity: value }),
    }),
    settingRow("Iconos", segmented(ICON_OPTIONS, iconSize, (value) => patch({ iconSize: value }))),
    settingRow(
      "Opciones",
      (() => {
        const chips = document.createElement("div");
        chips.className = "chips";
        chips.append(
          toggleChip("Nombres", folder.showNames !== false, (value) => patch({ showNames: value })),
          toggleChip("Recuadro", folder.showTiles !== false, (value) => patch({ showTiles: value }))
        );
        return chips;
      })()
    )
  );

  return wrap;
}

function buildCard(folder) {
  const patch = (payload) => window.launcherAPI.setStyle(folder.id, payload);

  const item = document.createElement("li");
  item.className = "folder-card";
  item.dataset.folderId = folder.id;
  item.innerHTML = `
    <header>
      <button class="chevron" type="button" aria-label="Mostrar u ocultar"></button>
      <input class="folder-name" value="" />
      <span class="meta"></span>
    </header>
    <div class="body">
      <div class="apps-title">Apps</div>
      <div class="app-list"></div>
      <p class="drop-note">Arrastra .exe o accesos directos aquí</p>
      <div class="actions">
        <button type="button" data-add>Agregar apps</button>
        <button type="button" class="danger" data-delete>Eliminar carpeta</button>
      </div>
    </div>
  `;

  const nameInput = item.querySelector(".folder-name");
  nameInput.value = folder.name;
  nameInput.addEventListener("change", async () => {
    await window.launcherAPI.renameFolder(folder.id, nameInput.value);
  });
  item.querySelector(".meta").textContent = `${folder.apps?.length || 0} apps`;

  const body = item.querySelector(".body");
  body.prepend(buildSettings(folder, patch));

  const list = item.querySelector(".app-list");
  (folder.apps || []).forEach((app) => {
    const row = document.createElement("div");
    row.className = "app-row";
    row.innerHTML = `<span class="icon"></span><span class="label"></span><button type="button" class="ghost">Quitar</button>`;
    setIcon(row.querySelector(".icon"), app);
    row.querySelector(".label").textContent = app.name;
    row.querySelector("button").addEventListener("click", async () => {
      await window.launcherAPI.removeApp(folder.id, app.id);
    });
    list.appendChild(row);
  });

  const header = item.querySelector("header");
  header.addEventListener("click", (event) => {
    if (event.target.closest("input")) return;
    const open = item.classList.toggle("open");
    if (open) openFolders.add(folder.id);
    else openFolders.delete(folder.id);
  });
  if (openFolders.has(folder.id)) item.classList.add("open");

  item.addEventListener("dragover", (event) => {
    if (!Array.from(event.dataTransfer?.types || []).includes("Files")) return;
    event.preventDefault();
    item.classList.add("drop");
  });
  item.addEventListener("dragleave", () => item.classList.remove("drop"));
  item.addEventListener("drop", async (event) => {
    event.preventDefault();
    item.classList.remove("drop");
    openFolders.add(folder.id);
    // Array (no FileList): el puente conserva la ruta de cada archivo así.
    await window.launcherAPI.addDroppedFiles(folder.id, Array.from(event.dataTransfer.files || []));
  });

  item.querySelector("[data-add]").addEventListener("click", async () => {
    await window.launcherAPI.pickApps(folder.id);
  });
  item.querySelector("[data-delete]").addEventListener("click", async () => {
    openFolders.delete(folder.id);
    await window.launcherAPI.deleteFolder(folder.id);
  });

  return item;
}

function render(folders) {
  foldersEl.replaceChildren();
  if (!folders.length) {
    const empty = document.createElement("li");
    empty.className = "folder-card empty";
    empty.textContent = "Todavía no hay carpetas. Crea una para empezar.";
    foldersEl.appendChild(empty);
    return;
  }

  folders.forEach((folder) => foldersEl.appendChild(buildCard(folder)));
}

async function refresh() {
  const data = await window.launcherAPI.listFolders();
  render(data.folders);
}

document.getElementById("add-folder").addEventListener("click", async () => {
  await window.launcherAPI.createFolder();
  refresh();
});

document.getElementById("hide").addEventListener("click", () => {
  window.launcherAPI.hide();
});

loginEl.addEventListener("change", async () => {
  await window.launcherAPI.setLogin(loginEl.checked);
});

window.launcherAPI.onUpdated((payload) => render(payload.folders));

async function init() {
  loginEl.checked = await window.launcherAPI.getLogin();
  await refresh();
}

init();
