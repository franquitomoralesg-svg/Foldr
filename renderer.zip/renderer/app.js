const overlay = document.getElementById("overlay");
const backdrop = document.getElementById("backdrop");
const folder = document.getElementById("folder");
const previewEl = document.getElementById("preview");
const labelEl = document.getElementById("folder-label");
const emojiEl = document.getElementById("folder-emoji");
const titleEl = document.getElementById("folder-title");
const appsContainer = document.getElementById("apps-container");
const appMenu = document.getElementById("app-menu");
const renameBox = document.getElementById("rename-box");
const renameInput = document.getElementById("rename-input");

const DRAG_THRESHOLD = 6;
const AUTOSCROLL_EDGE = 30;
const ICON_BOX = { small: 54, normal: 66, large: 80 };
const FOLDER_SIZE_LIMITS = { min: 120, max: 280 };
const DEFAULT_SIZE = 180;
const DEFAULT_OPACITY = 25;
let apps = [];
let dragAppId = null;
let isOpen = false;
let animating = false;
// Invalida los temporizadores de las animaciones anteriores.
let animToken = 0;
let drag = null;
let menuAppId = null;

function setIcon(node, app) {
  node.replaceChildren();
  if (!app) {
    node.classList.add("is-empty");
    return;
  }
  node.classList.remove("is-empty");
  if (app.icon && String(app.icon).startsWith("data:")) {
    const image = document.createElement("img");
    image.src = app.icon;
    image.alt = app.name || "";
    node.appendChild(image);
    return;
  }
  node.textContent = (app.name || "?").slice(0, 1).toUpperCase();
}

function renderPreview() {
  previewEl.replaceChildren();
  const first = apps.slice(0, 3);
  const rest = apps.slice(3);

  for (let index = 0; index < 3; index += 1) {
    const cell = document.createElement("div");
    cell.className = "app-icon-large";
    setIcon(cell, first[index]);
    previewEl.appendChild(cell);
  }

  const mini = document.createElement("div");
  mini.className = "mini-grid";
  const count = rest.length;
  const dim = count > 9 ? 4 : count > 4 ? 3 : 2;
  mini.style.gridTemplateColumns = `repeat(${dim}, 1fr)`;
  mini.style.gridTemplateRows = `repeat(${dim}, 1fr)`;
  const slots = dim * dim;
  const visible = rest.slice(0, slots);
  for (let index = 0; index < slots; index += 1) {
    const cell = document.createElement("div");
    cell.className = "app-icon-small";
    setIcon(cell, visible[index]);
    mini.appendChild(cell);
  }
  previewEl.appendChild(mini);
}

function hideAppMenu() {
  appMenu.hidden = true;
  renameBox.hidden = true;
  menuAppId = null;
}

function showAppMenu(event, app) {
  menuAppId = app.id;
  renameBox.hidden = true;
  renameInput.value = app.name;
  appMenu.hidden = false;
  const pad = 8;
  const x = Math.min(event.clientX, window.innerWidth - appMenu.offsetWidth - pad);
  const y = Math.min(event.clientY, window.innerHeight - appMenu.offsetHeight - pad);
  appMenu.style.left = `${Math.max(pad, x)}px`;
  appMenu.style.top = `${Math.max(pad, y)}px`;
}

function orderedIdsFromDom() {
  return Array.from(appsContainer.querySelectorAll(".app-item")).map((element) => element.dataset.appId);
}

function draggingItem() {
  return appsContainer.querySelector(".app-item.is-dragging");
}

function clearAppDrag() {
  dragAppId = null;
  appsContainer.classList.remove("is-reordering");
  appsContainer.querySelectorAll(".app-item").forEach((element) => {
    element.classList.remove("is-dragging");
  });
}

function autoscrollApps(event) {
  const box = appsContainer.getBoundingClientRect();
  if (event.clientY < box.top + AUTOSCROLL_EDGE) {
    appsContainer.scrollTop -= 14;
  } else if (event.clientY > box.bottom - AUTOSCROLL_EDGE) {
    appsContainer.scrollTop += 14;
  }
}

// Mueve el icono arrastrado al hueco donde está el cursor.
function previewReorder(event, target) {
  const dragged = draggingItem();
  if (!dragged || dragged === target) return;
  const box = target.getBoundingClientRect();
  const after = event.clientX > box.left + box.width / 2;
  appsContainer.insertBefore(dragged, after ? target.nextSibling : target);
}

async function commitAppOrder() {
  if (!dragAppId) return;
  const order = orderedIdsFromDom();
  const byId = new Map(apps.map((item) => [item.id, item]));
  const next = order.map((id) => byId.get(id)).filter(Boolean);
  clearAppDrag();
  if (next.length !== apps.length) return;
  if (next.every((item, index) => item === apps[index])) return;
  apps = next;
  renderPreview();
  await window.folderAPI.reorder(order);
}

function renderApps() {
  appsContainer.replaceChildren();
  apps.forEach((appItem) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "app-item";
    button.draggable = true;
    button.dataset.appId = appItem.id;
    button.innerHTML = `<span class="icon"></span><span class="name"></span>`;
    setIcon(button.querySelector(".icon"), appItem);
    button.querySelector(".name").textContent = appItem.name;
    button.title = `${appItem.name} · arrastra para mover de sitio`;
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      hideAppMenu();
      await window.folderAPI.launch(appItem.id);
    });
    button.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      event.stopPropagation();
      showAppMenu(event, appItem);
    });
    button.addEventListener("dragstart", (event) => {
      dragAppId = appItem.id;
      button.classList.add("is-dragging");
      appsContainer.classList.add("is-reordering");
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", appItem.id);
      event.stopPropagation();
    });
    button.addEventListener("dragover", (event) => {
      if (!dragAppId || appItem.id === dragAppId) return;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      previewReorder(event, button);
      autoscrollApps(event);
    });
    button.addEventListener("drop", (event) => {
      if (!dragAppId) return;
      event.preventDefault();
      event.stopPropagation();
      commitAppOrder();
    });
    button.addEventListener("dragend", () => clearAppDrag());
    appsContainer.appendChild(button);
  });
}

function clamp(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

// La opacidad del panel (0-100) se traduce al alfa del cristal.
function glassAlpha(opacity) {
  return 0.04 + (clamp(opacity, 0, 100, DEFAULT_OPACITY) / 100) * 0.56;
}

function applyAppearance(data) {
  const color = /^#[0-9a-fA-F]{6}$/.test(data.color || "") ? data.color : "";
  const size = clamp(data.size, FOLDER_SIZE_LIMITS.min, FOLDER_SIZE_LIMITS.max, DEFAULT_SIZE);
  const iconSize = Object.prototype.hasOwnProperty.call(ICON_BOX, data.iconSize)
    ? data.iconSize
    : "normal";
  const root = document.documentElement;

  root.style.setProperty("--folder-size", `${size}px`);
  root.style.setProperty("--glass-alpha", glassAlpha(data.opacity).toFixed(3));
  root.style.setProperty("--icon-box", `${ICON_BOX[iconSize]}px`);

  folder.classList.toggle("has-tint", Boolean(color));
  if (color) {
    folder.style.setProperty("--tint", color);
  } else {
    folder.style.removeProperty("--tint");
  }
  folder.classList.toggle("hide-names", data.showNames === false);
  folder.classList.toggle("no-tiles", data.showTiles === false);

  emojiEl.textContent = data.emoji || "";
  labelEl.textContent = [data.emoji, data.name || "Carpeta"].filter(Boolean).join(" ");

  // El nombre va pegado al borde de abajo: hay que recolocarlo si cambia el tamaño.
  if (!isOpen && !animating) compactFolderBox();
}

function applyFolder(data) {
  if (!data) return;
  apps = data.apps || [];
  if (document.activeElement !== titleEl) {
    titleEl.textContent = data.name || "Carpeta";
  }
  applyAppearance(data);
  renderPreview();
  renderApps();
}

function cssLength(name, fallback) {
  const value = parseFloat(getComputedStyle(document.documentElement).getPropertyValue(name));
  return Number.isFinite(value) ? value : fallback;
}

function setFolderPosition(x, y) {
  const left = Math.round(x);
  const top = Math.round(y);
  folder.style.left = `${left}px`;
  folder.style.top = `${top}px`;
  labelEl.style.left = `${left}px`;
  labelEl.style.top = `${top + cssLength("--folder-size", 180) + 2}px`;
}

function compactFolderBox() {
  const inset = cssLength("--folder-inset", 20);
  folder.style.width = "";
  folder.style.height = "";
  setFolderPosition(inset, inset);
}

async function openFolder() {
  if (isOpen || animating) return;
  animating = true;
  const token = ++animToken;

  const layout = await window.folderAPI.expand();
  const { work, compactBounds, folderInset } = layout;
  const startX = compactBounds.x - work.x + folderInset;
  const startY = compactBounds.y - work.y + folderInset;

  compactFolderBox();
  setFolderPosition(startX, startY);
  overlay.hidden = false;
  document.body.classList.add("is-open");

  requestAnimationFrame(() => {
    overlay.classList.add("visible");
    folder.classList.add("is-open");
    // El tamaño vive en las variables CSS --open-width / --open-height.
    const openWidth = cssLength("--open-width", 430);
    const openHeight = cssLength("--open-height", 570);
    setFolderPosition((work.width - openWidth) / 2, (work.height - openHeight) / 2);
  });

  window.setTimeout(() => {
    // Si mientras se abría se lanzó una app, la carpeta ya volvió a su sitio.
    if (token !== animToken) return;
    isOpen = true;
    animating = false;
  }, 480);
}

// La ventana ya se encogió (se abrió una app): dejamos el estado igual, sin animar.
function resetToCompact() {
  animToken += 1;
  hideAppMenu();
  overlay.classList.remove("visible");
  overlay.hidden = true;
  folder.classList.remove("is-open", "is-dragging", "is-drop-target");
  document.body.classList.remove("is-open");
  isOpen = false;
  animating = false;
  drag = null;
  compactFolderBox();
}

async function closeFolder() {
  // También vale durante la apertura: el token anterior queda invalidado, así
  // que su temporizador ya no puede dejar la carpeta abierta por su cuenta.
  if (!isOpen && !animating) return;
  hideAppMenu();
  animating = true;
  const token = ++animToken;

  const layout = await window.folderAPI.getLayout();
  const { work, compactBounds, folderInset } = layout;
  const endX = compactBounds.x - work.x + folderInset;
  const endY = compactBounds.y - work.y + folderInset;

  overlay.classList.remove("visible");
  folder.classList.remove("is-open");
  setFolderPosition(endX, endY);
  document.body.classList.remove("is-open");

  window.setTimeout(async () => {
    if (token !== animToken) return;
    overlay.hidden = true;
    compactFolderBox();
    await window.folderAPI.compact();
    isOpen = false;
    animating = false;
  }, 480);
}

function onPointerDown(event) {
  if (isOpen || event.button !== 0) return;
  drag = {
    pointerId: event.pointerId,
    startX: event.screenX,
    startY: event.screenY,
    originX: event.screenX,
    originY: event.screenY,
    moved: false,
  };
  folder.setPointerCapture(event.pointerId);
}

async function onPointerMove(event) {
  if (!drag || event.pointerId !== drag.pointerId || isOpen) return;

  const dx = event.screenX - drag.originX;
  const dy = event.screenY - drag.originY;
  if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;

  if (!drag.moved) {
    drag.moved = true;
    folder.classList.add("is-dragging");
    const layout = await window.folderAPI.getLayout();
    drag.winX = layout.bounds.x;
    drag.winY = layout.bounds.y;
    drag.startX = event.screenX;
    drag.startY = event.screenY;
  }

  const x = drag.winX + (event.screenX - drag.startX);
  const y = drag.winY + (event.screenY - drag.startY);
  window.folderAPI.move(x, y);
}

async function onPointerUp(event) {
  if (!drag || event.pointerId !== drag.pointerId) return;
  const wasClick = !drag.moved;
  if (drag.moved) await window.folderAPI.savePosition();
  folder.classList.remove("is-dragging");
  drag = null;
  if (wasClick) openFolder();
}

function isFileDrag(event) {
  return Array.from(event.dataTransfer?.types || []).includes("Files");
}

function onDragOver(event) {
  if (!isFileDrag(event)) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "copy";
  folder.classList.add("is-drop-target");
}

function onDragLeave(event) {
  if (event.target === folder || !folder.contains(event.relatedTarget)) {
    folder.classList.remove("is-drop-target");
  }
}

async function onDrop(event) {
  event.preventDefault();
  // Evita que el manejador global lo agregue otra vez.
  event.stopPropagation();
  folder.classList.remove("is-drop-target");
  const files = Array.from(event.dataTransfer?.files || []);
  if (!files.length) return;
  // Array (no FileList): el puente conserva la ruta de cada archivo así.
  await window.folderAPI.addDroppedFiles(files);
}

appMenu.addEventListener("click", async (event) => {
  const action = event.target.closest("[data-action]")?.dataset.action;
  if (!action || !menuAppId) return;
  event.stopPropagation();

  if (action === "rename") {
    renameBox.hidden = false;
    renameInput.focus();
    renameInput.select();
    return;
  }

  if (action === "rename-save") {
    await window.folderAPI.appAction({
      appId: menuAppId,
      action: "rename",
      name: renameInput.value,
    });
    hideAppMenu();
    return;
  }

  await window.folderAPI.appAction({ appId: menuAppId, action });
  hideAppMenu();
});

renameInput.addEventListener("keydown", async (event) => {
  if (event.key === "Enter" && menuAppId) {
    event.preventDefault();
    await window.folderAPI.appAction({
      appId: menuAppId,
      action: "rename",
      name: renameInput.value,
    });
    hideAppMenu();
  }
});

folder.addEventListener("pointerdown", onPointerDown);
// El nombre se arrastra y se pincha igual que la carpeta.
labelEl.addEventListener("pointerdown", onPointerDown);
folder.addEventListener("contextmenu", (event) => {
  event.preventDefault();
  event.stopPropagation();
  hideAppMenu();
  window.folderAPI.openMenu();
});
folder.addEventListener("pointermove", onPointerMove);
folder.addEventListener("pointerup", onPointerUp);
folder.addEventListener("pointercancel", onPointerUp);
appsContainer.addEventListener("dragover", (event) => {
  if (!dragAppId) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "move";
  autoscrollApps(event);
});
appsContainer.addEventListener("drop", (event) => {
  if (!dragAppId) return;
  event.preventDefault();
  commitAppOrder();
});

folder.addEventListener("dragover", onDragOver);
folder.addEventListener("dragleave", onDragLeave);
folder.addEventListener("drop", onDrop);
document.addEventListener("dragover", (event) => {
  if (isFileDrag(event)) event.preventDefault();
});
document.addEventListener("drop", async (event) => {
  if (!isFileDrag(event)) return;
  event.preventDefault();
  await window.folderAPI.addDroppedFiles(Array.from(event.dataTransfer.files));
});

backdrop.addEventListener("click", () => {
  hideAppMenu();
  closeFolder();
});

folder.addEventListener("click", (event) => {
  if (isOpen) event.stopPropagation();
  if (!appMenu.contains(event.target)) hideAppMenu();
});

titleEl.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    titleEl.blur();
  }
});

titleEl.addEventListener("blur", async () => {
  await window.folderAPI.rename(titleEl.textContent.trim());
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    if (!appMenu.hidden) {
      hideAppMenu();
      return;
    }
    closeFolder();
  }
});

window.folderAPI.onUpdated((payload) => applyFolder(payload));
window.folderAPI.onCollapsed(() => resetToCompact());

async function init() {
  applyFolder(await window.folderAPI.getState());
}

init();
