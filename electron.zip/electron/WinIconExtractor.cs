using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

internal static class Program
{
    private const int SIIGBF_BIGGERSIZEOK = 0x01;
    private const int SIIGBF_ICONONLY = 0x04;

    [StructLayout(LayoutKind.Sequential)]
    private struct SIZE
    {
        public int cx;
        public int cy;
        public SIZE(int w, int h) { cx = w; cy = h; }
    }

    [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IShellItemImageFactory
    {
        [PreserveSig]
        int GetImage(SIZE size, int flags, out IntPtr phbm);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    private static extern void SHCreateItemFromParsingName(
        [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
        IntPtr pbc,
        [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
        out IShellItemImageFactory ppv);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHDefExtractIcon(
        string pszIconFile,
        int iIndex,
        uint uFlags,
        ref IntPtr phiconLarge,
        ref IntPtr phiconSmall,
        uint nIconSize);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    [DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr hIcon);

    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length < 1)
        {
            return 1;
        }

        string filePath = args[0];
        int index = 0;
        int size = 256;
        if (args.Length > 1) int.TryParse(args[1], out index);
        if (args.Length > 2) int.TryParse(args[2], out size);
        if (size < 16) size = 256;

        try
        {
            Bitmap bitmap =
                FromShellItem(filePath, size) ??
                FromDefExtract(filePath, index, size) ??
                FromAssociated(filePath);

            if (bitmap == null)
            {
                return 2;
            }

            using (bitmap)
            using (var stream = new MemoryStream())
            {
                bitmap.Save(stream, ImageFormat.Png);
                Console.Write(Convert.ToBase64String(stream.ToArray()));
            }
            return 0;
        }
        catch
        {
            return 3;
        }
    }

    private static Bitmap FromShellItem(string filePath, int size)
    {
        try
        {
            IShellItemImageFactory factory;
            SHCreateItemFromParsingName(
                filePath,
                IntPtr.Zero,
                typeof(IShellItemImageFactory).GUID,
                out factory);
            IntPtr hbitmap;
            int hr = factory.GetImage(new SIZE(size, size), SIIGBF_BIGGERSIZEOK | SIIGBF_ICONONLY, out hbitmap);
            if (hr != 0 || hbitmap == IntPtr.Zero)
            {
                hr = factory.GetImage(new SIZE(size, size), SIIGBF_BIGGERSIZEOK, out hbitmap);
            }
            if (hr != 0 || hbitmap == IntPtr.Zero)
            {
                return null;
            }

            try
            {
                using (var raw = Image.FromHbitmap(hbitmap))
                {
                    return CopyBitmap(raw);
                }
            }
            finally
            {
                DeleteObject(hbitmap);
            }
        }
        catch
        {
            return null;
        }
    }

    private static Bitmap FromDefExtract(string filePath, int index, int size)
    {
        IntPtr large = IntPtr.Zero;
        IntPtr small = IntPtr.Zero;
        try
        {
            uint packed = (uint)size | ((uint)48 << 16);
            int hr = SHDefExtractIcon(filePath, index, 0, ref large, ref small, packed);
            if (hr != 0 || large == IntPtr.Zero)
            {
                return null;
            }

            using (Icon icon = Icon.FromHandle(large))
            {
                return CopyBitmap(icon.ToBitmap());
            }
        }
        catch
        {
            return null;
        }
        finally
        {
            if (large != IntPtr.Zero) DestroyIcon(large);
            if (small != IntPtr.Zero) DestroyIcon(small);
        }
    }

    private static Bitmap FromAssociated(string filePath)
    {
        try
        {
            using (Icon icon = Icon.ExtractAssociatedIcon(filePath))
            {
                if (icon == null) return null;
                return CopyBitmap(icon.ToBitmap());
            }
        }
        catch
        {
            return null;
        }
    }

    private static Bitmap CopyBitmap(Image source)
    {
        var copy = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        using (var graphics = Graphics.FromImage(copy))
        {
            graphics.Clear(Color.Transparent);
            graphics.DrawImage(source, 0, 0, source.Width, source.Height);
        }
        return copy;
    }
}
