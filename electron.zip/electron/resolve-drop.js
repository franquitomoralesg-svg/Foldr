const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");
const { app, shell } = require("electron");

const execFileAsync = promisify(execFile);

const ICON_SIZE = 256;
const SHELL_ICON_FLAGS = 0x01 | 0x04; // BIGGERSIZEOK | ICONONLY

// Extrae el icono que muestra el Explorador (256 px, con alfa). SHGetFileInfo
// devuelve el icono genérico cuando la caché de iconos de Windows está obsoleta,
// por eso usamos IShellItemImageFactory.
const SHELL_ICON_CLASS = `
using System;
using System.Runtime.InteropServices;

public static class ShellIconImage
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SIZE
    {
        public int cx;
        public int cy;
        public SIZE(int width, int height) { cx = width; cy = height; }
    }

    [ComImport]
    [Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShellItemImageFactory
    {
        [PreserveSig]
        int GetImage(SIZE size, int flags, out IntPtr phbm);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    private static extern void SHCreateItemFromParsingName(
        [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
        IntPtr pbc,
        [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
        out IShellItemImageFactory ppv);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    public static IntPtr GetHBitmap(string filePath, int size, int flags)
    {
        IShellItemImageFactory factory;
        SHCreateItemFromParsingName(filePath, IntPtr.Zero, typeof(IShellItemImageFactory).GUID, out factory);
        IntPtr hbitmap;
        int hr = factory.GetImage(new SIZE(size, size), flags, out hbitmap);
        if (hr != 0) return IntPtr.Zero;
        return hbitmap;
    }

    public static void Release(IntPtr hbitmap)
    {
        if (hbitmap != IntPtr.Zero) DeleteObject(hbitmap);
    }
}
`;

function quoteForPowerShell(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function encodePowerShell(script) {
  return Buffer.from(script, "utf16le").toString("base64");
}

// Devuelve un Map<ruta, data URL> con los iconos del Shell en una sola llamada.
async function extractShellIcons(paths) {
  const icons = new Map();
  if (process.platform !== "win32") return icons;

  const targets = Array.from(new Set(paths || [])).filter(
    (item) => typeof item === "string" && item && fs.existsSync(item)
  );
  if (!targets.length) return icons;

  const script = `
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore
Add-Type -Language CSharp -TypeDefinition @'
${SHELL_ICON_CLASS}
'@

function ConvertTo-IconBase64([string] $path, [int] $size) {
  $hbitmap = [ShellIconImage]::GetHBitmap($path, $size, ${SHELL_ICON_FLAGS})
  if ($hbitmap -eq [IntPtr]::Zero) { return '' }
  try {
    $source = [System.Windows.Interop.Imaging]::CreateBitmapSourceFromHBitmap(
      $hbitmap,
      [IntPtr]::Zero,
      [System.Windows.Int32Rect]::Empty,
      [System.Windows.Media.Imaging.BitmapSizeOptions]::FromEmptyOptions())
    $encoder = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
    $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($source))
    $stream = New-Object System.IO.MemoryStream
    $encoder.Save($stream)
    return [Convert]::ToBase64String($stream.ToArray())
  } finally {
    [ShellIconImage]::Release($hbitmap)
  }
}

$index = 0
foreach ($path in @(${targets.map(quoteForPowerShell).join(", ")})) {
  $encoded = ''
  try { $encoded = ConvertTo-IconBase64 $path ${ICON_SIZE} } catch { $encoded = '' }
  Write-Output ($index.ToString() + '|' + $encoded)
  $index += 1
}
`;

  try {
    const { stdout } = await execFileAsync(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-STA", "-EncodedCommand", encodePowerShell(script)],
      { windowsHide: true, maxBuffer: 64 * 1024 * 1024, timeout: 120000 }
    );
    for (const line of stdout.split(/\r?\n/)) {
      const match = line.trim().match(/^(\d+)\|([A-Za-z0-9+/=]*)$/);
      if (!match) continue;
      const target = targets[Number(match[1])];
      if (target && match[2]) {
        icons.set(target, `data:image/png;base64,${match[2]}`);
      }
    }
  } catch {
    return icons;
  }
  return icons;
}

function displayNameFromPath(filePath) {
  return path.basename(filePath, path.extname(filePath));
}

function parseUrlFile(filePath) {
  const content = fs.readFileSync(filePath, "utf8");
  const match = content.match(/^\s*URL\s*=\s*(.+)\s*$/im);
  return match ? match[1].trim() : "";
}

function candidateIconPaths(sourcePath) {
  if (!sourcePath) return [];
  const list = [sourcePath];
  if (!path.isAbsolute(sourcePath)) {
    const name = sourcePath.endsWith(".exe") ? sourcePath : `${sourcePath}.exe`;
    list.push(
      path.join(process.env.SystemRoot || "C:\\Windows", name),
      path.join(process.env.SystemRoot || "C:\\Windows", "System32", name),
      path.join(process.env.SystemRoot || "C:\\Windows", "SysWOW64", name)
    );
  }
  return list.filter((item, index, all) => item && all.indexOf(item) === index);
}

async function iconFromElectron(sourcePath) {
  try {
    if (!sourcePath || !fs.existsSync(sourcePath)) return "";
    const image = await app.getFileIcon(sourcePath, { size: "large" });
    if (!image || image.isEmpty()) return "";
    return image.toDataURL();
  } catch {
    return "";
  }
}

async function iconFromPowershell(sourcePath) {
  if (process.platform !== "win32" || !sourcePath || !fs.existsSync(sourcePath)) return "";
  const script = `
    Add-Type -AssemblyName System.Drawing
    $path = ${JSON.stringify(sourcePath)}
    try {
      $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)
      if ($null -eq $icon) { return }
      $bitmap = $icon.ToBitmap()
      $stream = New-Object System.IO.MemoryStream
      $bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
      [Convert]::ToBase64String($stream.ToArray())
    } catch {}
  `;
  try {
    const { stdout } = await execFileAsync(
      "powershell.exe",
      ["-NoProfile", "-STA", "-Command", script],
      { windowsHide: true, maxBuffer: 1024 * 1024 }
    );
    const base64 = stdout.trim().replace(/\s+/g, "");
    return base64 ? `data:image/png;base64,${base64}` : "";
  } catch {
    return "";
  }
}

async function iconDataUrl(sourcePath, options = {}) {
  const candidates = candidateIconPaths(sourcePath);

  if (options.allowShell !== false) {
    const shellIcons = await extractShellIcons(candidates);
    for (const candidate of candidates) {
      const shellIcon = shellIcons.get(candidate);
      if (shellIcon) return shellIcon;
    }
  }

  for (const candidate of candidates) {
    const electronIcon = await iconFromElectron(candidate);
    if (electronIcon) return electronIcon;
    const psIcon = await iconFromPowershell(candidate);
    if (psIcon) return psIcon;
  }
  return "";
}

async function resolveDroppedPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();

  if (ext === ".lnk") {
    const shortcut = shell.readShortcutLink(filePath);
    const target = shortcut.target || filePath;
    const iconFile = shortcut.icon ? shortcut.icon.split(",")[0] : "";
    return {
      name: displayNameFromPath(filePath),
      type: "command",
      target,
      args: shortcut.args || "",
      icon:
        (await iconDataUrl(filePath)) ||
        (await iconDataUrl(iconFile)) ||
        (await iconDataUrl(target)),
    };
  }

  if (ext === ".url") {
    const target = parseUrlFile(filePath);
    return {
      name: displayNameFromPath(filePath),
      type: "url",
      target,
      args: "",
      icon: await iconDataUrl(filePath),
    };
  }

  const stats = fs.statSync(filePath);
  if (stats.isDirectory()) {
    return {
      name: displayNameFromPath(filePath) || path.basename(filePath),
      type: "path",
      target: filePath,
      args: "",
      icon: await iconDataUrl(filePath),
    };
  }

  return {
    name: displayNameFromPath(filePath),
    type: ext === ".exe" ? "command" : "path",
    target: filePath,
    args: "",
    icon: await iconDataUrl(filePath),
  };
}

async function resolveSystemCommand(name, target, type = "command") {
  const resolvedPath = path.isAbsolute(target) ? target : fileIfExists(target);
  const launchTarget = resolvedPath || target;
  return {
    name,
    type,
    target: launchTarget,
    args: "",
    icon: await iconDataUrl(launchTarget) || (await iconDataUrl(target)),
  };
}

function fileIfExists(commandName) {
  const candidates = [
    path.join(process.env.SystemRoot || "C:\\Windows", commandName),
    path.join(process.env.SystemRoot || "C:\\Windows", "System32", commandName),
    path.join(process.env.SystemRoot || "C:\\Windows", "SysWOW64", commandName),
    path.join(
      process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)",
      "Microsoft",
      "Edge",
      "Application",
      commandName
    ),
    path.join(process.env.ProgramFiles || "C:\\Program Files", "Microsoft", "Edge", "Application", commandName),
  ];
  return candidates.find((candidate) => fs.existsSync(candidate)) || "";
}

module.exports = {
  resolveDroppedPath,
  fileIfExists,
  resolveSystemCommand,
  iconDataUrl,
  extractShellIcons,
};
