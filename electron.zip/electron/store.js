const fs = require("fs");
const path = require("path");
const { randomUUID } = require("crypto");

const FOLDER_SIZE = { min: 120, max: 280, default: 180 };
const FOLDER_OPACITY = { min: 0, max: 100, default: 25 };
const ICON_SIZES = ["small", "normal", "large"];

function storePath(userData) {
  return path.join(userData, "folders.json");
}

function emptyState() {
  return { folders: [] };
}

function readState(userData) {
  const file = storePath(userData);
  if (!fs.existsSync(file)) return emptyState();
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!parsed || !Array.isArray(parsed.folders)) return emptyState();
    return parsed;
  } catch {
    return emptyState();
  }
}

function writeState(userData, state) {
  const file = storePath(userData);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(state, null, 2), "utf8");
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

function resolveFolderSize(value) {
  return clampNumber(value, FOLDER_SIZE.min, FOLDER_SIZE.max, FOLDER_SIZE.default);
}

function resolveOpacity(value) {
  return clampNumber(value, FOLDER_OPACITY.min, FOLDER_OPACITY.max, FOLDER_OPACITY.default);
}

// Devuelve solo los ajustes válidos de un cambio de estilo.
function normalizeAppearance(patch = {}) {
  const appearance = {};
  if (typeof patch.color === "string") {
    appearance.color = /^#[0-9a-fA-F]{6}$/.test(patch.color) ? patch.color.toLowerCase() : "";
  }
  if (typeof patch.emoji === "string") {
    appearance.emoji = Array.from(patch.emoji.trim()).slice(0, 2).join("");
  }
  if (patch.size !== undefined) appearance.size = resolveFolderSize(patch.size);
  if (patch.opacity !== undefined) appearance.opacity = resolveOpacity(patch.opacity);
  if (ICON_SIZES.includes(patch.iconSize)) appearance.iconSize = patch.iconSize;
  if (typeof patch.showNames === "boolean") appearance.showNames = patch.showNames;
  if (typeof patch.showTiles === "boolean") appearance.showTiles = patch.showTiles;
  return appearance;
}

function createFolderRecord(partial = {}) {
  return {
    id: partial.id || randomUUID(),
    name: partial.name || "Nueva carpeta",
    x: Number.isFinite(partial.x) ? partial.x : 80,
    y: Number.isFinite(partial.y) ? partial.y : 80,
    color: typeof partial.color === "string" ? partial.color : "",
    emoji: typeof partial.emoji === "string" ? partial.emoji : "",
    size: resolveFolderSize(partial.size),
    opacity: resolveOpacity(partial.opacity),
    iconSize: ICON_SIZES.includes(partial.iconSize) ? partial.iconSize : "normal",
    showNames: partial.showNames !== false,
    showTiles: partial.showTiles !== false,
    apps: Array.isArray(partial.apps) ? partial.apps : [],
  };
}

module.exports = {
  storePath,
  readState,
  writeState,
  createFolderRecord,
  normalizeAppearance,
  resolveFolderSize,
  resolveOpacity,
  FOLDER_SIZE,
  FOLDER_OPACITY,
  ICON_SIZES,
};
