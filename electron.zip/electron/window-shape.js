// La ventana del widget es más grande que la carpeta (queda margen para el
// nombre, la sombra y el efecto de hover). Con estas formas la ventana solo
// captura los píxeles que se ven: el resto deja pasar los clics al escritorio.

function roundedRectRows({ x, y, width, height, radius }) {
  const rows = [];
  const r = Math.max(0, Math.min(radius, Math.floor(Math.min(width, height) / 2)));
  for (let row = 0; row < height; row += 1) {
    let dy = 0;
    if (row < r) dy = r - row - 0.5;
    else if (row >= height - r) dy = row - (height - r) + 0.5;
    const inset = dy > 0 ? Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy))) : 0;
    rows.push({
      x: x + inset,
      y: y + row,
      width: Math.max(1, width - inset * 2),
      height: 1,
    });
  }
  return rows;
}

// Carpeta redondeada + la banda del nombre que va debajo.
function widgetShape({ windowSize, inset, folderSize, radius, padding = 0, labelHeight = 0 }) {
  const size = folderSize + padding * 2;
  const left = inset - padding;
  const rows = roundedRectRows({
    x: left,
    y: inset - padding,
    width: size,
    height: size,
    radius: radius + padding,
  });

  const labelTop = inset + folderSize + 1;
  const labelBottom = Math.min(windowSize, labelTop + labelHeight);
  if (labelHeight > 0 && labelBottom > labelTop) {
    rows.push({ x: left, y: labelTop, width: size, height: labelBottom - labelTop });
  }

  return rows;
}

function containsPoint(rects, px, py) {
  return rects.some(
    (rect) => px >= rect.x && px < rect.x + rect.width && py >= rect.y && py < rect.y + rect.height
  );
}

module.exports = { roundedRectRows, widgetShape, containsPoint };
