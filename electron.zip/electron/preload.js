const { contextBridge, ipcRenderer, webUtils } = require("electron");

// Ojo: hay que pasar un Array real (Array.from(files)). Si se pasa el FileList
// tal cual, el puente lo convierte en objetos sin ruta y getPathForFile
// devuelve "" (las apps se caerían sin agregar nada y sin dar error).
function pathsFromFiles(files) {
  const list = Array.from(files || []);
  const paths = list.map((file) => webUtils.getPathForFile(file)).filter(Boolean);
  if (list.length && !paths.length) {
    console.warn(
      "No se pudo leer la ruta de los archivos: pasa un Array real (Array.from(files)), no un FileList."
    );
  }
  return paths;
}

contextBridge.exposeInMainWorld("folderAPI", {
  getState: () => ipcRenderer.invoke("folder:get-state"),
  getLayout: () => ipcRenderer.invoke("folder:get-layout"),
  expand: () => ipcRenderer.invoke("folder:expand"),
  compact: () => ipcRenderer.invoke("folder:compact"),
  move: (x, y) => ipcRenderer.send("folder:move", { x, y }),
  savePosition: () => ipcRenderer.invoke("folder:save-position"),
  launch: (id) => ipcRenderer.invoke("folder:launch", id),
  rename: (name) => ipcRenderer.invoke("folder:rename", name),
  setStyle: (patch) => ipcRenderer.send("folder:update-style", patch),
  openMenu: () => ipcRenderer.send("folder:menu"),
  reorder: (ids) => ipcRenderer.invoke("folder:reorder", ids),
  appAction: (payload) => ipcRenderer.invoke("folder:app-action", payload),
  addDroppedFiles: (files) => ipcRenderer.invoke("folder:add-paths", pathsFromFiles(files)),
  onUpdated: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on("folder:updated", listener);
    return () => ipcRenderer.removeListener("folder:updated", listener);
  },
  // Avisa que la ventana ya se encogió por su cuenta (al abrir una app).
  onCollapsed: (callback) => {
    const listener = () => callback();
    ipcRenderer.on("folder:collapsed", listener);
    return () => ipcRenderer.removeListener("folder:collapsed", listener);
  },
});

contextBridge.exposeInMainWorld("launcherAPI", {
  listFolders: () => ipcRenderer.invoke("launcher:list"),
  createFolder: () => ipcRenderer.invoke("launcher:create"),
  renameFolder: (id, name) => ipcRenderer.invoke("launcher:rename", { id, name }),
  setStyle: (id, style) => ipcRenderer.invoke("launcher:update-style", { id, ...style }),
  deleteFolder: (id) => ipcRenderer.invoke("launcher:delete", id),
  pickApps: (id) => ipcRenderer.invoke("launcher:pick-apps", id),
  removeApp: (folderId, appId) => ipcRenderer.invoke("launcher:remove-app", { folderId, appId }),
  addDroppedFiles: (folderId, files) =>
    ipcRenderer.invoke("launcher:add-paths", { id: folderId, paths: pathsFromFiles(files) }),
  getLogin: () => ipcRenderer.invoke("launcher:get-login"),
  setLogin: (enabled) => ipcRenderer.invoke("launcher:set-login", enabled),
  hide: () => ipcRenderer.invoke("launcher:hide"),
  onUpdated: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on("launcher:updated", listener);
    return () => ipcRenderer.removeListener("launcher:updated", listener);
  },
});
