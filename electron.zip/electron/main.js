const {
  app,
  BrowserWindow,
  ipcMain,
  screen,
  shell,
  Tray,
  Menu,
  dialog,
  nativeImage,
} = require("electron");
const path = require("path");
const fs = require("fs");
const net = require("net");
const { spawn } = require("child_process");
const { randomUUID } = require("crypto");
const {
  readState,
  writeState,
  createFolderRecord,
  normalizeAppearance,
  resolveFolderSize,
  resolveOpacity,
  ICON_SIZES,
  FOLDER_SIZE,
} = require("./store");
const {
  resolveDroppedPath,
  fileIfExists,
  iconDataUrl,
  extractShellIcons,
} = require("./resolve-drop");
const { widgetShape } = require("./window-shape");
const { folderMenuTemplate } = require("./folder-menu");

const FOLDER_INSET = 20;
// Ventana del widget por defecto: carpeta + margen para la sombra y el nombre.
const COMPACT_SIZE = FOLDER_SIZE.default + FOLDER_INSET * 2;
// Debe coincidir con el border-radius de .folder en styles.css.
const FOLDER_RADIUS = 28;
const LABEL_HEIGHT = 18;
const SHAPE_PADDING = 4;
// Arranque del sistema: las carpetas salen igual, pero sin abrir el panel.
const HIDDEN_FLAG = "--hidden";
const startedHidden = process.argv.includes(HIDDEN_FLAG);
// Candado global entre copias del programa (portable, instalado, desarrollo).
// Un puerto local es más fiable que un archivo con un PID: no hay PID reciclado
// ni archivo viejo que limpiar, y al cerrarse el proceso el puerto queda libre.
const INSTANCE_PORT = 47615;
const INSTANCE_TOKEN = "foldr";
// En el .exe empaquetado el nombre del producto cambia la carpeta de datos
// (%APPDATA%\Foldr) y ni siquiera existiría la de siempre.
const dataDirName = "carpetas-hyperos";
const userDataDir = path.join(app.getPath("appData"), dataDirName);
if (app.isPackaged) {
  app.setPath("userData", userDataDir);
}
// Migración de datos del nombre anterior: %APPDATA%\Foldr -> %APPDATA%\carpetas-hyperos
function migrateUserDataIfNeeded() {
  const target = path.join(userDataDir, "folders.json");
  if (fs.existsSync(target)) return;
  const legacy = path.join(app.getPath("appData"), "Foldr", "folders.json");
  try {
    if (fs.existsSync(legacy)) {
      fs.mkdirSync(userDataDir, { recursive: true });
      fs.copyFileSync(legacy, target);
    }
  } catch (error) {
    console.warn("No se pudo migrar la configuración anterior:", error.message);
  }
}
// Sube este número para volver a extraer los iconos ya guardados.
const ICON_CACHE_VERSION = 2;

let state = { folders: [] };
let managerWin = null;
let tray = null;
let quitting = false;
const widgets = new Map();

function save() {
  writeState(app.getPath("userData"), state);
}

function folderById(id) {
  return state.folders.find((folder) => folder.id === id);
}

function widgetFromEvent(event) {
  const contentsId = event.sender.id;
  for (const [folderId, widget] of widgets) {
    if (widget.win && !widget.win.isDestroyed() && widget.win.webContents.id === contentsId) {
      return { folderId, widget };
    }
  }
  return null;
}

function publicFolders() {
  return state.folders.map((folder) => ({
    id: folder.id,
    name: folder.name,
    color: folder.color || "",
    emoji: folder.emoji || "",
    size: resolveFolderSize(folder.size),
    opacity: resolveOpacity(folder.opacity),
    iconSize: ICON_SIZES.includes(folder.iconSize) ? folder.iconSize : "normal",
    showNames: folder.showNames !== false,
    showTiles: folder.showTiles !== false,
    appCount: folder.apps.length,
    apps: folder.apps,
  }));
}

function broadcastFolders() {
  const payload = { folders: publicFolders() };
  if (managerWin && !managerWin.isDestroyed()) {
    managerWin.webContents.send("launcher:updated", payload);
  }
}

function hasIcon(item) {
  return typeof item.icon === "string" && item.icon.startsWith("data:image");
}

async function refreshMissingIcons() {
  const pending = [];
  for (const folder of state.folders) {
    for (const item of folder.apps) {
      // Los accesos a protocolos o URLs no tienen icono de archivo: si se
      // reintentaran, cada arranque lanzaría PowerShell para nada.
      const canHaveIcon = item.type !== "protocol" && item.type !== "url";
      if (canHaveIcon && (state.iconCacheVersion !== ICON_CACHE_VERSION || !hasIcon(item))) {
        pending.push({ item, source: item.iconFile || item.target });
      }
    }
  }
  if (!pending.length) return false;

  const shellIcons = await extractShellIcons(pending.map((entry) => entry.source));
  let iconsChanged = false;
  for (const { item, source } of pending) {
    const icon =
      shellIcons.get(source) ||
      (await iconDataUrl(source, { allowShell: false })) ||
      item.icon ||
      "";
    if (icon && icon !== item.icon) {
      item.icon = icon;
      iconsChanged = true;
    }
  }

  // La caché queda al día aunque algún icono no se pueda extraer (accesos a
  // protocolos o rutas inexistentes): esos se reintentan solos en el próximo inicio.
  const versionChanged = state.iconCacheVersion !== ICON_CACHE_VERSION;
  state.iconCacheVersion = ICON_CACHE_VERSION;
  if (iconsChanged || versionChanged) save();
  return iconsChanged;
}

function sendFolderUpdate(folderId) {
  const folder = folderById(folderId);
  const widget = widgets.get(folderId);
  if (folder && widget && !widget.win.isDestroyed()) {
    widget.win.webContents.send("folder:updated", folder);
  }
  broadcastFolders();
}

function workAreaFor(win) {
  return screen.getDisplayMatching(win.getBounds()).workArea;
}

// Pregunta si el puerto lo tiene otra copia nuestra (no otro programa cualquiera).
function askRunningInstance() {
  return new Promise((resolve) => {
    const socket = net.connect(INSTANCE_PORT, "127.0.0.1");
    let answer = "";
    const finish = (isOurs) => {
      socket.destroy();
      resolve(isOurs);
    };
    socket.setTimeout(600, () => finish(false));
    socket.setEncoding("utf8");
    socket.on("connect", () => socket.write(`${INSTANCE_TOKEN}:show-panel`));
    socket.on("data", (chunk) => {
      answer += chunk;
      if (answer.includes("ok")) finish(true);
      else if (answer.length > 32) finish(false);
    });
    socket.on("error", () => finish(false));
  });
}

// Devuelve true si esta es la única copia corriendo. Si hay otra, le pide que
// enseñe su panel y devuelve false (esta se cierra sin crear nada).
async function claimSingleInstance() {
  const server = net.createServer((socket) => {
    socket.setEncoding("utf8");
    socket.on("data", (chunk) => {
      if (!String(chunk).includes(INSTANCE_TOKEN)) return;
      // Otra copia intentó abrirse: le pasamos el relevo al panel que ya existe.
      showManager();
      try {
        socket.write("ok");
      } catch {
        // Si no se pudo contestar, da igual: la otra copia se cierra igual.
      }
    });
    socket.on("error", () => {});
  });

  // "ours" = puerto conseguido · "busy" = lo tiene otro · "failed" = no se pudo
  const listen = await new Promise((resolve) => {
    server.once("error", (error) => resolve(error.code === "EADDRINUSE" ? "busy" : "failed"));
    server.listen(INSTANCE_PORT, "127.0.0.1", () => resolve("ours"));
  });

  if (listen === "ours") {
    return true;
  }
  if (listen === "failed") {
    // Sin puerto propio (permisos, por ejemplo): seguimos, el candado de
    // Electron ya evita duplicados con la misma carpeta de datos.
    return true;
  }
  if (await askRunningInstance()) return false;
  // El puerto lo ocupa otro programa: no es asunto nuestro, arrancamos igual.
  console.warn(`El puerto ${INSTANCE_PORT} está ocupado por otro programa; se sigue sin candado global.`);
  return true;
}

// Deja pinchable solo lo que se ve: la carpeta (con un pelín de margen para el
// hover) y la banda del nombre. El margen invisible pasa los clics al escritorio.
function applyWidgetShape(widget) {
  const { win } = widget;
  if (!win || win.isDestroyed() || typeof win.setShape !== "function") return;

  if (widget.expanded) {
    const { width, height } = win.getBounds();
    win.setShape([{ x: 0, y: 0, width, height }]);
    return;
  }

  win.setShape(
    widgetShape({
      windowSize: widget.compactBounds.width,
      inset: FOLDER_INSET,
      folderSize: widget.folderSize,
      radius: FOLDER_RADIUS,
      padding: SHAPE_PADDING,
      labelHeight: LABEL_HEIGHT,
    })
  );
}

function compactBoundsFor(folder, position = {}) {
  const size = resolveFolderSize(folder?.size) + FOLDER_INSET * 2;
  return { x: position.x ?? 0, y: position.y ?? 0, width: size, height: size };
}

// Cambia el tamaño del widget (y su forma) sin moverlo de sitio.
function resizeWidget(widget, folder) {
  if (!widget || !widget.win || widget.win.isDestroyed()) return;
  widget.folderSize = resolveFolderSize(folder?.size);
  widget.compactBounds = compactBoundsFor(folder, widget.compactBounds);
  if (widget.expanded) return;
  widget.win.setBounds(widget.compactBounds, false);
  applyWidgetShape(widget);
}

function updateFolderAppearance(folder, patch = {}) {
  if (!folder) return null;
  Object.assign(folder, normalizeAppearance(patch));
  resizeWidget(widgets.get(folder.id), folder);
  save();
  sendFolderUpdate(folder.id);
  return folder;
}

function nextFolderPosition() {
  const work = screen.getPrimaryDisplay().workArea;
  const index = state.folders.length;
  return {
    x: work.x + 48 + (index % 4) * (COMPACT_SIZE + 24),
    y: work.y + 48 + Math.floor(index / 4) * (COMPACT_SIZE + 24),
  };
}

function createFolderWindow(folder) {
  if (widgets.has(folder.id)) {
    const existing = widgets.get(folder.id);
    if (existing.win && !existing.win.isDestroyed()) return existing.win;
  }

  const compactBounds = compactBoundsFor(folder, { x: folder.x, y: folder.y });

  const win = new BrowserWindow({
    x: compactBounds.x,
    y: compactBounds.y,
    width: COMPACT_SIZE,
    height: COMPACT_SIZE,
    frame: false,
    transparent: true,
    backgroundColor: "#00000000",
    resizable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: false,
    hasShadow: false,
    thickFrame: false,
    focusable: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  const widget = {
    win,
    compactBounds,
    expanded: false,
    folderSize: resolveFolderSize(folder.size),
  };
  widgets.set(folder.id, widget);
  applyWidgetShape(widget);

  win.loadFile(path.join(__dirname, "..", "renderer", "index.html"), {
    query: { folderId: folder.id },
  });
  win.webContents.on("will-navigate", (event) => event.preventDefault());
  win.once("ready-to-show", () => win.showInactive());
  win.on("closed", () => {
    widgets.delete(folder.id);
  });

  return win;
}

function destroyFolderWindow(folderId) {
  const widget = widgets.get(folderId);
  if (widget && widget.win && !widget.win.isDestroyed()) {
    widget.win.destroy();
  }
  widgets.delete(folderId);
}

// Apps de la carpeta del primer arranque. El nombre se ve al instante; la ruta
// y el icono reales se resuelven después (resolverlos antes, uno por app con
// PowerShell, retrasaba el primer arranque unos 4 s).
const SEED_APPS = [
  ["Archivos", "explorer.exe"],
  ["Notas", "notepad.exe"],
  ["Calc", "calc.exe"],
  ["CMD", "cmd.exe"],
  ["Paint", "mspaint.exe"],
  ["Ajustes", "control.exe"],
  ["Edge", "msedge.exe"],
];

let pendingSeedApps = [];

function seedIfNeeded() {
  if (state.folders.length) return;

  const apps = SEED_APPS.map(([name, target]) => ({
    id: randomUUID(),
    name,
    type: "command",
    target,
    args: "",
    icon: "",
  }));
  const position = nextFolderPosition();
  state.folders.push(
    createFolderRecord({
      name: "Productividad",
      x: position.x,
      y: position.y,
      apps,
    })
  );
  save();
  pendingSeedApps = apps.map((item, index) => ({ item, target: SEED_APPS[index][1] }));
}

// Rutas + iconos de la carpeta semilla, en un solo PowerShell (antes: uno por app).
async function finishSeedInBackground() {
  const pending = pendingSeedApps;
  pendingSeedApps = [];
  if (!pending.length) return;

  const entries = pending.map(({ item, target }) => ({
    item,
    source: path.isAbsolute(target) ? target : fileIfExists(target) || target,
  }));
  const icons = await extractShellIcons(entries.map((entry) => entry.source));
  for (const { item, source } of entries) {
    item.target = source;
    item.icon = icons.get(source) || (await iconDataUrl(source, { allowShell: false })) || "";
  }
  save();
  for (const folder of state.folders) sendFolderUpdate(folder.id);
}

// Lo que no hace falta para ver las carpetas se hace después, sin bloquear el
// arranque: ventanas primero, trabajo lento en segundo plano.
async function afterStartupWork() {
  try {
    await finishSeedInBackground();
    if (await refreshMissingIcons()) {
      for (const folder of state.folders) sendFolderUpdate(folder.id);
    }
  } catch (error) {
    console.warn("Trabajo de arranque pendiente:", error.message);
  }
}

function showManager() {
  if (managerWin && !managerWin.isDestroyed()) {
    managerWin.show();
    managerWin.focus();
    return;
  }

  managerWin = new BrowserWindow({
    width: 620,
    height: 760,
    minWidth: 480,
    minHeight: 560,
    title: "Foldr",
    icon: path.join(__dirname, "..", "assets", "icon.png"),
    autoHideMenuBar: true,
    show: false,
    backgroundColor: "#11141c",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  managerWin.webContents.on("will-navigate", (event) => event.preventDefault());
  managerWin.loadFile(path.join(__dirname, "..", "renderer", "manager.html"));
  managerWin.once("ready-to-show", () => managerWin.show());
  managerWin.on("close", (event) => {
    if (!quitting) {
      event.preventDefault();
      managerWin.hide();
    }
  });
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, "..", "assets", "tray.png"));
  tray = new Tray(icon.isEmpty() ? nativeImage.createFromPath(process.execPath) : icon);
  tray.setToolTip("Foldr");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: "Abrir panel", click: () => showManager() },
      { label: "Nueva carpeta", click: () => createNewFolder() },
      { type: "separator" },
      {
        label: "Salir",
        click: () => {
          quitting = true;
          app.quit();
        },
      },
    ])
  );
  tray.on("double-click", () => showManager());
}

async function addPathsToFolder(folder, paths) {
  let added = 0;
  for (const filePath of paths) {
    try {
      const resolved = await resolveDroppedPath(filePath);
      if (!resolved.target) continue;
      const duplicate = folder.apps.some(
        (item) => item.target.toLowerCase() === resolved.target.toLowerCase()
      );
      if (duplicate) continue;
      folder.apps.push({ id: randomUUID(), ...resolved });
      added += 1;
    } catch (error) {
      console.error("No se pudo agregar", filePath, error);
    }
  }
  if (added) save();
  return added;
}

function createNewFolder() {
  const position = nextFolderPosition();
  const folder = createFolderRecord({
    name: `Carpeta ${state.folders.length + 1}`,
    x: position.x,
    y: position.y,
    apps: [],
  });
  state.folders.push(folder);
  save();
  createFolderWindow(folder);
  broadcastFolders();
  return folder;
}

async function launchApp(item) {
  if (item.type === "protocol" || item.type === "url") {
    await shell.openExternal(item.target);
    return { ok: true };
  }

  if (item.type === "path") {
    const error = await shell.openPath(item.target);
    return error ? { ok: false, error } : { ok: true };
  }

  const extraArgs = Array.isArray(item.args) ? item.args.join(" ") : item.args || "";
  const useShell = !path.isAbsolute(item.target) || Boolean(extraArgs);
  const command = extraArgs ? `"${item.target}" ${extraArgs}` : item.target;
  const child = spawn(command, {
    detached: true,
    stdio: "ignore",
    shell: useShell,
    windowsHide: true,
  });
  // Sin este oyente, un destino que ya no existe (acceso directo viejo) lanzaría
  // un error sin manejar y podría tumbar el launcher.
  child.on("error", (error) => {
    console.warn(`No se pudo abrir ${item.target}: ${error.message}`);
  });
  child.unref();
  return { ok: true };
}

// Cuando se abre algo (una app, el Explorador, un diálogo) las carpetas se
// apartan: las que estén abiertas vuelven a su sitio. Sin eso su capa a
// pantalla completa (y encima de todo) taparía justo lo que acaba de abrirse.
function stepFoldersAside() {
  for (const widget of widgets.values()) {
    if (!widget.win || widget.win.isDestroyed() || !widget.expanded) continue;
    widget.expanded = false;
    widget.win.setAlwaysOnTop(false);
    widget.win.setBounds(widget.compactBounds, false);
    applyWidgetShape(widget);
    if (!widget.win.webContents.isDestroyed()) {
      widget.win.webContents.send("folder:collapsed");
    }
  }
}

ipcMain.handle("folder:get-state", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return { name: "Carpeta", apps: [] };
  return folderById(found.folderId);
});

ipcMain.handle("folder:get-layout", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return null;
  const { widget } = found;
  return {
    work: workAreaFor(widget.win),
    bounds: widget.win.getBounds(),
    compactBounds: widget.compactBounds,
    expanded: widget.expanded,
    folderInset: FOLDER_INSET,
  };
});

ipcMain.on("folder:move", (event, { x, y }) => {
  const found = widgetFromEvent(event);
  if (!found || found.widget.expanded) return;
  found.widget.win.setPosition(Math.round(x), Math.round(y));
  found.widget.compactBounds = { ...found.widget.win.getBounds() };
});

ipcMain.handle("folder:save-position", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return null;
  const folder = folderById(found.folderId);
  const bounds = found.widget.win.getBounds();
  found.widget.compactBounds = { ...bounds };
  if (folder) {
    folder.x = bounds.x;
    folder.y = bounds.y;
    save();
  }
  return bounds;
});

ipcMain.handle("folder:expand", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return null;
  const { widget } = found;
  if (widget.expanded) {
    return {
      work: workAreaFor(widget.win),
      compactBounds: widget.compactBounds,
      folderInset: FOLDER_INSET,
    };
  }
  widget.compactBounds = { ...widget.win.getBounds() };
  widget.expanded = true;
  widget.win.setAlwaysOnTop(true, "floating");
  widget.win.setBounds(workAreaFor(widget.win), false);
  applyWidgetShape(widget);
  widget.win.focus();
  return {
    work: workAreaFor(widget.win),
    compactBounds: widget.compactBounds,
    folderInset: FOLDER_INSET,
  };
});

ipcMain.handle("folder:compact", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return null;
  const { widget } = found;
  widget.expanded = false;
  widget.win.setAlwaysOnTop(false);
  widget.win.setBounds(widget.compactBounds, false);
  applyWidgetShape(widget);
  return widget.compactBounds;
});

ipcMain.handle("folder:launch", async (event, appId) => {
  const found = widgetFromEvent(event);
  if (!found || typeof appId !== "string") return { ok: false, error: "id inválido" };
  const folder = folderById(found.folderId);
  const item = folder?.apps.find((appItem) => appItem.id === appId);
  if (!item) return { ok: false, error: "app no encontrada" };
  try {
    stepFoldersAside();
    return await launchApp(item);
  } catch (error) {
    return { ok: false, error: error.message };
  }
});

function revealApp(item) {
  const target = item?.target;
  if (!target || item.type === "protocol" || item.type === "url") return;
  if (fs.existsSync(target)) {
    shell.showItemInFolder(target);
  }
}

function showAppProperties(item) {
  const target = item?.target;
  if (!target || !fs.existsSync(target)) return;
  spawn(
    "powershell.exe",
    [
      "-NoProfile",
      "-STA",
      "-Command",
      `(New-Object -ComObject Shell.Application).NameSpace(${JSON.stringify(
        path.dirname(target)
      )}).ParseName(${JSON.stringify(path.basename(target))}).InvokeVerb('properties')`,
    ],
    { detached: true, stdio: "ignore", windowsHide: true }
  ).unref();
}

ipcMain.handle("folder:app-action", async (event, payload = {}) => {
  const found = widgetFromEvent(event);
  if (!found) return null;
  const folder = folderById(found.folderId);
  const item = folder?.apps.find((appItem) => appItem.id === payload.appId);
  if (!folder || !item) return null;

  if (payload.action === "open") {
    stepFoldersAside();
    await launchApp(item);
  } else if (payload.action === "rename" && typeof payload.name === "string") {
    item.name = payload.name.trim() || item.name;
    save();
  } else if (payload.action === "remove") {
    folder.apps = folder.apps.filter((appItem) => appItem.id !== item.id);
    save();
  } else if (payload.action === "reveal") {
    stepFoldersAside();
    revealApp(item);
  } else if (payload.action === "properties") {
    stepFoldersAside();
    showAppProperties(item);
  }

  sendFolderUpdate(found.folderId);
  return folder;
});

ipcMain.handle("folder:reorder", (event, ids) => {
  const found = widgetFromEvent(event);
  if (!found || !Array.isArray(ids)) return null;
  const folder = folderById(found.folderId);
  if (!folder) return null;

  const byId = new Map(folder.apps.map((item) => [item.id, item]));
  const ordered = ids.map((id) => byId.get(id)).filter(Boolean);
  // Si la lista no coincide con la carpeta, no tocamos nada.
  if (ordered.length !== folder.apps.length) return folder;

  folder.apps = ordered;
  save();
  sendFolderUpdate(found.folderId);
  return folder;
});

ipcMain.handle("folder:rename", (event, name) => {
  const found = widgetFromEvent(event);
  if (!found || typeof name !== "string") return null;
  const folder = folderById(found.folderId);
  folder.name = name.trim() || folder.name;
  save();
  sendFolderUpdate(found.folderId);
  return folder;
});

ipcMain.handle("folder:add-paths", async (event, paths) => {
  const found = widgetFromEvent(event);
  if (!found || !Array.isArray(paths)) return { added: 0 };
  const folder = folderById(found.folderId);
  const added = await addPathsToFolder(folder, paths);
  sendFolderUpdate(found.folderId);
  return { added };
});

ipcMain.handle("launcher:list", () => ({
  folders: publicFolders(),
}));

ipcMain.handle("launcher:create", () => {
  const folder = createNewFolder();
  return { id: folder.id, name: folder.name, appCount: 0 };
});

ipcMain.handle("launcher:rename", (_event, { id, name }) => {
  const folder = folderById(id);
  if (!folder || typeof name !== "string") return null;
  folder.name = name.trim() || folder.name;
  save();
  sendFolderUpdate(id);
  return folder;
});

ipcMain.handle("launcher:update-style", (_event, payload = {}) => {
  const folder = folderById(payload.id);
  if (!folder) return null;
  Object.assign(folder, normalizeAppearance(payload));
  resizeWidget(widgets.get(folder.id), folder);
  save();
  // Solo se avisa al widget: el panel ya lo sabe (si no, se rehacía mientras
  // se arrastra un deslizador y se perdía el arrastre).
  const widget = widgets.get(folder.id);
  if (widget && !widget.win.isDestroyed()) {
    widget.win.webContents.send("folder:updated", folder);
  }
  return folder;
});

ipcMain.on("folder:update-style", (event, patch = {}) => {
  const found = widgetFromEvent(event);
  if (!found) return;
  const folder = updateFolderAppearance(folderById(found.folderId), patch);
  if (folder) broadcastFolders();
});

ipcMain.on("folder:menu", (event) => {
  const found = widgetFromEvent(event);
  if (!found) return;
  const folder = folderById(found.folderId);
  if (!folder) return;
  const menu = Menu.buildFromTemplate(
    folderMenuTemplate({
      folder,
      onPatch: (patch) => {
        updateFolderAppearance(folder, patch);
        broadcastFolders();
      },
      onOpenPanel: () => showManager(),
    })
  );
  menu.popup({ window: found.widget.win });
});

ipcMain.handle("launcher:delete", (_event, id) => {
  state.folders = state.folders.filter((folder) => folder.id !== id);
  destroyFolderWindow(id);
  save();
  broadcastFolders();
  return { ok: true };
});

ipcMain.handle("launcher:remove-app", (_event, { folderId, appId }) => {
  const folder = folderById(folderId);
  if (!folder) return null;
  folder.apps = folder.apps.filter((item) => item.id !== appId);
  save();
  sendFolderUpdate(folderId);
  return folder;
});

ipcMain.handle("launcher:add-paths", async (_event, { id, paths }) => {
  const folder = folderById(id);
  if (!folder || !Array.isArray(paths)) return { added: 0 };
  const added = await addPathsToFolder(folder, paths);
  sendFolderUpdate(id);
  return { added };
});

ipcMain.handle("launcher:pick-apps", async (_event, id) => {
  const folder = folderById(id);
  if (!folder) return { added: 0 };
  const result = await dialog.showOpenDialog(managerWin, {
    title: "Agregar aplicaciones",
    properties: ["openFile", "multiSelections"],
    filters: [
      { name: "Aplicaciones y accesos directos", extensions: ["exe", "lnk", "url"] },
      { name: "Todos", extensions: ["*"] },
    ],
  });
  if (result.canceled) return { added: 0 };
  const added = await addPathsToFolder(folder, result.filePaths);
  sendFolderUpdate(id);
  return { added };
});

ipcMain.handle("launcher:get-login", () => app.getLoginItemSettings().openAtLogin);

// Arranque automático con --hidden: al encender el PC salen las carpetas y nada
// más (el panel se abre desde la bandeja o al volver a abrir el programa).
function loginItemArgs() {
  const args = app.isPackaged ? [] : [app.getAppPath()];
  return [...args, HIDDEN_FLAG];
}

function applyLoginItem(enabled) {
  app.setLoginItemSettings({
    openAtLogin: enabled,
    enabled,
    args: enabled ? loginItemArgs() : [],
  });
}

ipcMain.handle("launcher:set-login", (_event, enabled) => {
  applyLoginItem(Boolean(enabled));
  return app.getLoginItemSettings().openAtLogin;
});

ipcMain.handle("launcher:hide", () => {
  if (managerWin && !managerWin.isDestroyed()) managerWin.hide();
});

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => showManager());

  app.whenReady().then(async () => {
    // Antes de nada: si ya hay otra copia corriendo, esta se cierra sola.
    if (!(await claimSingleInstance())) {
      app.quit();
      return;
    }
    migrateUserDataIfNeeded();
    state = readState(app.getPath("userData"));
    // Primero lo que se ve: el registro semilla se crea al instante y las
    // carpetas se abren con los iconos ya guardados.
    seedIfNeeded();
    createTray();
    for (const folder of state.folders) {
      createFolderWindow(folder);
    }
    // Al encender el PC no se abre el panel: solo las carpetas, listas ya.
    if (!startedHidden || !state.folders.length) showManager();

    // Entradas de arranque creadas antes de este cambio: se les añade --hidden.
    if (app.getLoginItemSettings().openAtLogin) applyLoginItem(true);
    afterStartupWork();
  });

  app.on("window-all-closed", () => {
    // El launcher sigue en la bandeja aunque no haya ventanas.
  });

  app.on("before-quit", () => {
    quitting = true;
  });
}
