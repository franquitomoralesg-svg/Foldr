// Menú nativo al hacer clic derecho sobre una carpeta del escritorio.
const { ICON_SIZES, FOLDER_SIZE, resolveFolderSize, resolveOpacity } = require("./store");

const SIZE_PRESETS = [
  ["Pequeña", 140],
  ["Normal", 180],
  ["Grande", 220],
  ["Enorme", 260],
];

const ICON_LABELS = { small: "Chicos", normal: "Normales", large: "Grandes" };

const OPACITY_PRESETS = [
  ["Casi transparente", 5],
  ["Transparente", 15],
  ["Normal", 25],
  ["Opaca", 55],
  ["Muy opaca", 85],
];

function folderMenuTemplate({ folder, onPatch, onOpenPanel }) {
  const size = resolveFolderSize(folder.size);
  const opacity = resolveOpacity(folder.opacity);
  const iconSize = ICON_SIZES.includes(folder.iconSize) ? folder.iconSize : "normal";

  return [
    { label: `Configurar «${folder.name}»`, enabled: false },
    { type: "separator" },
    {
      label: "Tamaño de la carpeta",
      submenu: SIZE_PRESETS.map(([label, value]) => ({
        label: `${label} · ${value} px`,
        type: "radio",
        checked: size === value,
        click: () => onPatch({ size: value }),
      })),
    },
    {
      label: "Iconos",
      submenu: [
        ...ICON_SIZES.map((value) => ({
          label: ICON_LABELS[value],
          type: "radio",
          checked: iconSize === value,
          click: () => onPatch({ iconSize: value }),
        })),
        { type: "separator" },
        {
          label: "Nombres debajo del icono",
          type: "checkbox",
          checked: folder.showNames !== false,
          click: (item) => onPatch({ showNames: item.checked }),
        },
        {
          label: "Recuadro detrás del icono",
          type: "checkbox",
          checked: folder.showTiles !== false,
          click: (item) => onPatch({ showTiles: item.checked }),
        },
      ],
    },
    {
      label: "Opacidad",
      submenu: OPACITY_PRESETS.map(([label, value]) => ({
        label: `${label} · ${value}%`,
        type: "radio",
        checked: opacity === value,
        click: () => onPatch({ opacity: value }),
      })),
    },
    { type: "separator" },
    { label: "Abrir panel de configuración", click: () => onOpenPanel() },
  ];
}

module.exports = { folderMenuTemplate, SIZE_PRESETS, OPACITY_PRESETS, FOLDER_SIZE };
